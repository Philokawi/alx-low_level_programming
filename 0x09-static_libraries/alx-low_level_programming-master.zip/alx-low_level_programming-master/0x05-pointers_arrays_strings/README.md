introduction of arrays pointers and strings tasks
