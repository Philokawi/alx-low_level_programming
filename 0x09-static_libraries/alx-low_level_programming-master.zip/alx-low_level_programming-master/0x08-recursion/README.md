Recursion program solution of task 0 -7 + advanced

task 0: Write a function that prints a string, followed by a new line.
Prototype: void _puts_recursion(char *s);

task 1:1. Why is it so important to dream? Because, in my dreams we are together
write a function that prints a string in reverse.
Prototype: void _print_rev_recursion(char *s);

task 2: 2. Dreams feel real while we're in them. It's only when we wake up that we realize something was actually strange
Write a function that returns the length of a string.
prototype: int _strlen_recursion(char *s);

task 3:3. You mustn't be afraid to dream a little bigger, darling
Write a function that returns the factorial of a given number.
prototype: int factorial(int n);
If n is lower than 0, the function should return -1 to indicate an error
Factorial of 0 is 1

task4:Write a function that returns the value of x raised to the power of y.
prototype: int _pow_recursion(int x, int y);
If y is lower than 0, the function should return -1

task 5:Write a function that returns the natural square root of a number.
Prototype: int _sqrt_recursion(int n);
If n does not have a natural square root, the function should return -1

task 6:6. Inception. Is it possible?
Write a function that returns 1 if the input integer is a prime number, otherwise return 0.
Prototype: int is_prime_number(int n);

task 7: advanced
task 8: advanced
