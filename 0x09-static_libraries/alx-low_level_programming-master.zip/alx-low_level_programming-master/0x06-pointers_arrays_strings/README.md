more pointers and arrays tasks
