assignment tasks for debugging errors in the programs
