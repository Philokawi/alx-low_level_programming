#include <stdio.h>
/**
 * main - Entry point
 * Description:
 * Return: 0
 */
int main(void)
{
puts("\"Programming is like building a multilingual puzzle");
return (0);
}
