familiarize myself with C language 
