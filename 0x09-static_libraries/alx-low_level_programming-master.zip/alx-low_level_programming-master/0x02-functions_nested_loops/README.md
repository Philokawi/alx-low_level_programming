my task for nested loop
