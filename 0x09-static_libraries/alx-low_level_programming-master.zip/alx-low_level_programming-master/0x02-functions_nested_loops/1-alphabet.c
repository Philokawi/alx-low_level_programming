#include "main.h"
/**
 * print_alphabet -> print the lowercase alphabet
 */
void print_alphabet(void)
{
	int j;

	for (j = 'a'; j <= 'z'; j++)
	{
		_putchar(j);
	}
	_putchar('\n');
}
